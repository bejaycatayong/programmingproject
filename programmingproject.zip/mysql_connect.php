<?php
/*
------------------------------------------------------------------------------------------------------
Script Name: mysql_connect.php
Author: <type your name>
Description: To connect to the MySQL server and database
------------------------------------------------------------------------------------------------------
*/
$username = "root";
$password = "";
$database = "dbfinaltermproject";

$conn = mysqli_connect("localhost", $username, $password, $database);

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
?>
