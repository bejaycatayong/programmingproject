<?php
session_start();
include 'mysql_connect.php';

if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit;
}

$user = $_SESSION['user'];

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $user_id = $user['id'];

    $profile_picture_path = $user['profile_picture'];

    if (isset($_FILES['profile_picture']) && $_FILES['profile_picture']['error'] == 0) {
        $upload_dir = 'uploads/profile_pictures/';
        if (!is_dir($upload_dir)) {
            mkdir($upload_dir, 0777, true);
        }

        $file_name = basename($_FILES['profile_picture']['name']);
        $target_file = $upload_dir . $user_id . '_' . $file_name;
        $file_type = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

        $allowed_types = ['jpg', 'jpeg', 'png', 'gif'];
        if (in_array($file_type, $allowed_types)) {
            if ($_FILES['profile_picture']['size'] <= 500000) { 
                if (move_uploaded_file($_FILES['profile_picture']['tmp_name'], $target_file)) {
                    $profile_picture_path = $target_file;
                } else {
                    echo "<script>alert('Error uploading the file. Please try again.');</script>";
                }
            } else {
                echo "<script>alert('File size exceeds the 500KB limit.');</script>";
            }
        } else {
            echo "<script>alert('Invalid file type. Only JPG, PNG, and GIF are allowed.');</script>";
        }
    }


    $stmt = $conn->prepare("UPDATE users SET name = ?, email = ?, profile_picture = ? WHERE id = ?");
    $stmt->bind_param("sssi", $name, $email, $profile_picture_path, $user_id);

    if ($stmt->execute()) {
        $_SESSION['user']['name'] = $name;
        $_SESSION['user']['email'] = $email;
        $_SESSION['user']['profile_picture'] = $profile_picture_path;
        echo "<script>alert('Profile updated successfully!');</script>";
        echo "<script>window.location.href = 'view_profile.php';</script>";
    } else {
        echo "<script>alert('Error updating profile. Please try again.');</script>";
    }

    $stmt->close();
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Profile</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            padding: 20px;
        }
        .container {
            max-width: 600px;
            margin: auto;
            background: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        input, button {
            width: 100%;
            margin: 10px 0;
            padding: 10px;
            font-size: 16px;
        }
        button {
            background-color: #003399;
            color: white;
            border: none;
            cursor: pointer;
        }
        button:hover {
            background-color: #FFD700;
            color: #003399;
        }
        .back {
            background-color: #f44336;
        }
        .back:hover {
            background-color: #d32f2f;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Edit Profile</h1>
    <form action="edit_profile.php" method="post" enctype="multipart/form-data">
    <label for="name">Name:</label>
    <input type="text" id="name" name="name" value="<?php echo htmlspecialchars($user['name']); ?>" required>

    <label for="email">Email:</label>
    <input type="email" id="email" name="email" value="<?php echo htmlspecialchars($user['email']); ?>" required>

    <label for="profile_picture">Upload Profile Picture:</label>
    <input type="file" id="profile_picture" name="profile_picture" accept="image/*">

    <button type="submit">Update Profile</button>
</form>

        <button class="back" onclick="window.location.href='<?php echo $user['role'] . "_dashboard.php"; ?>'">Back</button>
    </div>
</body>
</html>
