<?php
include 'mysql_connect.php';

$security_question = null;
$email = null; 

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['email']) && !isset($_POST['security_answer'])) {

        $email = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL);

        $stmt = $conn->prepare("SELECT security_question FROM users WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($stmt && $result->num_rows > 0) {
            $user = $result->fetch_assoc();
            $security_question = $user['security_question'];
        } else {
            echo "<script>alert('No user found with this email address or query failed.');</script>";
        }
    } elseif (isset($_POST['security_answer'])) {

        $email = $_POST['email'];
        $security_answer = $_POST['security_answer'];

        $stmt = $conn->prepare("SELECT * FROM users WHERE email = ? AND security_answer = ?");
        $stmt->bind_param("ss", $email, $security_answer);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            header("Location: reset_password.php?email=" . urlencode($email));
            exit;
        } else {
            echo "<script>alert('Incorrect security answer. Please try again.');</script>";
        }
    }
    $stmt->close();
    $conn->close();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Forgot Password</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            padding: 20px;
        }
        .container {
            max-width: 400px;
            margin: 100px auto;
            background: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        input, button {
            width: 100%;
            margin: 10px 0;
            padding: 10px;
        }
        button {
            background-color: #003399;
            color: white;
            border: none;
            cursor: pointer;
        }
        button:hover {
            background-color: #FFD700;
            color: #003399;
        }
        h1, h3 {
            color: #003399;
        }
    </style>
</head>
<body>
    <div class="container" style="text-align: center;">
        <?php if (!isset($security_question)) { ?>

            <h1>Forgot Password</h1>
            <form action="forgot_password.php" method="post">
                <input type="email" name="email" placeholder="Enter your email" required>
                <button type="submit">Submit</button>
                <p>Remember password? <a href="login.php">Log in</a></p>
            </form>
        <?php } else { ?>

            <h3>Security Question: <?php echo htmlspecialchars($security_question); ?></h3>
            <form action="forgot_password.php" method="post">
                <input type="hidden" name="email" value="<?php echo htmlspecialchars($email); ?>">
                <input type="text" name="security_answer" placeholder="Enter your answer" required>
                <button type="submit">Verify</button>
            </form>
        <?php } ?>
    </div>
</body>
</html>
