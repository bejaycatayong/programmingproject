<?php
session_start();
include 'mysql_connect.php';

if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit;
}

$user = $_SESSION['user'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Profile</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            padding: 20px;
        }
        .container {
            max-width: 600px;
            margin: auto;
            background: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        table {
            width: 100%;
            margin: 20px 0;
            border-collapse: collapse;
        }
       
       
        th, td {
            text-align: left;
            padding: 10px;
            border-bottom: 1px solid #ddd;
        }
        button {
            margin: 10px 0;
            padding: 10px;
            width: 48%;
            display: inline-block;
            font-size: 16px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        .edit {
            background-color: #003399;
            color: white;
        }
        .edit:hover {
            background-color: #FFD700;
            color: #003399;
        }
        .back {
            background-color: #f44336;
            color: white;
        }
        .back:hover {
            background-color: #d32f2f;
        }
        
    </style>
</head>
<body>
    <div class="container">
        <h1>My Profile</h1>
        <div class="profile">
        <img src="<?php echo htmlspecialchars($user['profile_picture']); ?>" alt="Profile Picture" style="width:150px; height:150px; border-radius:50%;"><br>
        </div>
        <table>
            <tr>
                <th>ID Number:</th>
                <td><?php echo htmlspecialchars($user['id_number']); ?></td>
            </tr>
            <tr>
                <th>Name:</th>
                <td><?php echo htmlspecialchars($user['name']); ?></td>
            </tr>
            <tr>
                <th>Email:</th>
                <td><?php echo htmlspecialchars($user['email']); ?></td>
            </tr>
            <tr>
                <th>Role:</th>
                <td><?php echo htmlspecialchars($user['role']); ?></td>
            </tr>
        </table>
        <button class="back" onclick="window.location.href='<?php echo $user['role'] . "_dashboard.php"; ?>'">Back</button>
        <button class="edit" onclick="window.location.href='edit_profile.php'">Edit Profile</button>
    </div>
</body>
</html>
