<?php
session_start();

if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit;
}

$user = $_SESSION['user']; 
include 'mysql_connect.php';

$stmt = $conn->prepare("SELECT * FROM tbviolations");
$stmt->execute();
$result = $stmt->get_result();

$violations = [];
while ($row = $result->fetch_assoc()) {
    $violations[] = $row;
}

$stmt->close();
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>List of Violations</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            padding: 20px;
        }
        .container {
            max-width: 800px;
            margin: auto;
            background: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
        }
        th, td {
            text-align: left;
            padding: 10px;
            border-bottom: 1px solid #ddd;
        }
        th {
            background-color: #003399;
            color: white;
        }
        button {
            margin: 10px 0;
            padding: 10px;
            width: 100%;
            background-color: #003399;
            color: white;
            border: none;
            border-radius: 5px;
            font-size: 16px;
            cursor: pointer;
        }
        button:hover {
            background-color: #FFD700;
            color: #003399;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>List of Violations and Sanctions</h1>
        <table>
            <thead>
                <tr>
                    <th>Violation</th>
                    <th>Sanction</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($violations)) { ?>
                    <tr>
                        <td colspan="2">No violations found.</td>
                    </tr>
                <?php } else { ?>
                    <?php foreach ($violations as $violation) { ?>
                        <tr>
                            <td><?php echo htmlspecialchars($violation['Violation']); ?></td>
                            <td><?php echo htmlspecialchars($violation['Sanction']); ?></td>
                        </tr>
                    <?php } ?>
                <?php } ?>
            </tbody>
        </table>
        <button class="back" onclick="window.location.href='<?php echo $user['role'] . "_dashboard.php"; ?>'">Back</button>
    </div>
</body>
</html>
