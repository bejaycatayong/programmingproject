<?php
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit;
}

include 'mysql_connect.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $student_id = $_POST['student_id'];
    $violation = $_POST['violation'];
    $sanction = $_POST['sanction'];
    $faculty_id = $_SESSION['user']['id'];

    $stmt = $conn->prepare("INSERT INTO tbadminreport (student_id, violation_id, sanction, admin_id) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("iisi", $student_id, $violation, $sanction, $faculty_id);
    $stmt->execute();
    $stmt->close();
    
    header("Location: faculty_dashboard.php");
    exit;
}
?>
