<?php
session_start();


if (!isset($_SESSION['user']) || $_SESSION['user']['role'] != 'admin') {
    header("Location: login.php");
    exit;
}

$user = $_SESSION['user'];
include 'mysql_connect.php';

$filters = [
    'student_id' => '',
    'violation_id' => '',
    'start_date' => '',
    'end_date' => ''
];
$reports = [];

$violations = [];
$stmt = $conn->prepare("SELECT violation_id, Violation FROM tbviolations");
$stmt->execute();
$result = $stmt->get_result();
while ($row = $result->fetch_assoc()) {
    $violations[] = $row;
}


if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $filters['student_id'] = $_POST['student_id'] ?? '';
    $filters['violation_id'] = $_POST['violation_id'] ?? '';
    $filters['start_date'] = $_POST['start_date'] ?? '';
    $filters['end_date'] = $_POST['end_date'] ?? '';


    if (!empty($filters['start_date']) && empty($filters['end_date'])) {
        echo "<script>alert('Please provide the End Date when you select a Start Date.');</script>";
        exit;
    }
    if (empty($filters['start_date']) && !empty($filters['end_date'])) {
        echo "<script>alert('Please provide the Start Date when you select an End Date.');</script>";
        exit;
    }

    $query = "
        SELECT ar.report_id, v.Violation, v.Sanction, ar.faculty_report, ar.report_date, ar.student_response, s.id_number AS StudentID, s.name AS StudentName
        FROM tbadminreport ar
        JOIN tbviolations v ON ar.violation_id = v.violation_id
        JOIN users s ON ar.student_id = s.id
        WHERE 1=1
    ";
    $params = [];
    $types = '';

    if (!empty($filters['student_id'])) {
        $query .= " AND s.id_number = ?";
        $params[] = $filters['student_id'];
        $types .= 's';
    }
    if (!empty($filters['violation_id'])) {
        $query .= " AND v.violation_id = ?";
        $params[] = $filters['violation_id'];
        $types .= 'i';
    }
    if (!empty($filters['start_date']) && !empty($filters['end_date'])) {
        $query .= " AND ar.report_date BETWEEN ? AND ?";
        $params[] = $filters['start_date'];
        $params[] = $filters['end_date'];
        $types .= 'ss';
    }

    $stmt = $conn->prepare($query);
    if (!empty($params)) {
        $stmt->bind_param($types, ...$params);
    }
    $stmt->execute();
    $result = $stmt->get_result();
    while ($row = $result->fetch_assoc()) {
        $reports[] = $row;
    }
    $stmt->close();
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Generate Reports</title>
    <style>
        button.backbtn {
        background-color: #003399; 
        width: 10%;  
        color: white;             
        border: none;             
        padding: 10px 20px;       
        font-size: 16px;          
        cursor: pointer;         
        transition: background-color 0.3s;
        border: none;
        border-radius: 5px;
        }

        button.backbtn:hover {
        background-color: #FFD700;
        color: #003399;
        }

        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            padding: 20px;
        }
        .container {
            max-width: 1000px;
            margin: auto;
            background: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        form {
            margin-bottom: 20px;
        }
        label {
            display: block;
        }
        .buttonbtn {
            width: 10%;
            padding: 10px;
            margin-bottom: 15px;
            margin-right: 100px;
            font-size: 16px;
        }
        input, select, button {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            margin-right: 10px;
            font-size: 16px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
        }
        th, td {
            text-align: left;
            padding: 10px;
            border-bottom: 1px solid #ddd;
        }
        th {
            background-color: #003399;
            color: white;
        }
        .export {
            background-color: #4CAF50;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            font-size: 16px;
            cursor: pointer;
            
        }
        .export:hover {
            background-color: #45a049;
        }
    </style>
    <script>

        function validateForm() {
            var startDate = document.getElementById("start_date").value;
            var endDate = document.getElementById("end_date").value;

            if (startDate && !endDate) {
                alert("Please provide the End Date when you select a Start Date.");
                return false;
            }
            if (!startDate && endDate) {
                alert("Please provide the Start Date when you select an End Date.");
                return false;
            }

            return true; 
        }

        function clearFilters() {
            document.getElementById("student_id").value = "";
            document.getElementById("violation_id").value = "";
            document.getElementById("start_date").value = "";
            document.getElementById("end_date").value = "";
        }
    </script>
</head>
<body>
    <div class="container">
    <button class="backbtn" onclick="window.location.href='<?php echo $user['role'] . "_dashboard.php"; ?>'">Back</button>
        <h1>Generate Reports</h1>

        <!-- Filter Form -->
        <form action="generate_reports.php" method="post" onsubmit="return validateForm()">
            <label for="student_id">Filter by Student ID:</label>
            <input type="text" id="student_id" name="student_id" value="<?php echo htmlspecialchars($filters['student_id']); ?>">

            <label for="violation_id">Filter by Violation:</label>
            <select id="violation_id" name="violation_id">
                <option value="">All Violations</option>
                <?php foreach ($violations as $violation) { ?>
                    <option value="<?php echo $violation['violation_id']; ?>" <?php echo $violation['violation_id'] == $filters['violation_id'] ? 'selected' : ''; ?>>
                        <?php echo htmlspecialchars($violation['Violation']); ?>
                    </option>
                <?php } ?>
            </select>

            <label for="start_date">Filter by Date Range (Start):</label>
            <input type="date" id="start_date" name="start_date" value="<?php echo htmlspecialchars($filters['start_date']); ?>">

            <label for="end_date">Filter by Date Range (End):</label>
            <input type="date" id="end_date" name="end_date" value="<?php echo htmlspecialchars($filters['end_date']); ?>">

            <button type="submit">Generate Report</button>
            <button type="button" onclick="clearFilters()">Clear Filters</button>
        </form>

        <form action="export_reports.php" method="get" style="margin-top: 20px;">
            <input type="hidden" name="student_id" value="<?php echo htmlspecialchars($filters['student_id']); ?>">
            <input type="hidden" name="violation_id" value="<?php echo htmlspecialchars($filters['violation_id']); ?>">
            <input type="hidden" name="start_date" value="<?php echo htmlspecialchars($filters['start_date']); ?>">
            <input type="hidden" name="end_date" value="<?php echo htmlspecialchars($filters['end_date']); ?>">
            <button type="submit" class="export">Export to CSV</button>
        </form>

        <h2>Report Results</h2>
        <table>
            <thead>
                <tr>
                    <th>Student ID</th>
                    <th>Student Name</th>
                    <th>Violation</th>
                    <th>Sanction</th>
                    <th>Faculty Report</th>
                    <th>Student Response</th>
                    <th>Report Date</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($reports)) { ?>
                    <tr>
                        <td colspan="7">No reports found for the selected filters.</td>
                    </tr>
                <?php } else { ?>
                    <?php foreach ($reports as $report) { ?>
                        <tr>
                            <td><?php echo htmlspecialchars($report['StudentID']); ?></td>
                            <td><?php echo htmlspecialchars($report['StudentName']); ?></td>
                            <td><?php echo htmlspecialchars($report['Violation']); ?></td>
                            <td><?php echo htmlspecialchars($report['Sanction']); ?></td>
                            <td><?php echo htmlspecialchars($report['faculty_report']); ?></td>
                            <td><?php echo htmlspecialchars($report['student_response']); ?></td>
                            <td><?php echo htmlspecialchars($report['report_date']); ?></td>
                        </tr>
                    <?php } ?>
                <?php } ?>
            </tbody>
        </table>
    </div>
</body>
</html>
