<?php
require_once 'mysql_connect.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id_number = $_POST['id_number'];
    $name = $_POST['name'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $role = $_POST['role'];
    $security_question = $_POST['security_question'];
    $security_answer = $_POST['security_answer'];

    // Server-side validation for numeric ID
    if (!ctype_digit($id_number)) {
        echo "<script>alert('ID Number must contain only numeric values.');</script>";
        echo "<script>window.location.href = 'registration.php';</script>";
        exit; // Stops the script from running further if the validation fails
    }

    // Default profile picture path
    $default_picture = 'uploads/profile_pictures/default.png'; 
    $profile_picture_path = $default_picture; 

    // Handling file upload for profile picture
    if (isset($_FILES['profile_picture']) && $_FILES['profile_picture']['error'] == 0) {
        $upload_dir = 'uploads/profile_pictures/';
        if (!is_dir($upload_dir)) {
            mkdir($upload_dir, 0777, true);
        }

        $file_name = basename($_FILES['profile_picture']['name']);
        $target_file = $upload_dir . $id_number . '_' . $file_name;
        $file_type = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

        $allowed_types = ['jpg', 'jpeg', 'png', 'gif'];
        if (in_array($file_type, $allowed_types)) {
            if ($_FILES['profile_picture']['size'] <= 500000) {
                if (move_uploaded_file($_FILES['profile_picture']['tmp_name'], $target_file)) {
                    $profile_picture_path = $target_file; 
                } else {
                    echo "<script>alert('Error uploading the profile picture. Using default picture.');</script>";
                }
            } else {
                echo "<script>alert('File size exceeds the 500KB limit. Using default picture.');</script>";
            }
        } else {
            echo "<script>alert('Invalid file type. Only JPG, PNG, and GIF are allowed. Using default picture.');</script>";
        }
    }

    // Check if email or ID number already exists in the database
    $stmt = $conn->prepare("SELECT id FROM users WHERE email = ? OR id_number = ?");
    $stmt->bind_param("ss", $email, $id_number);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        echo "<script>alert('Email or ID number already exists. Please try again.');</script>";
        echo "<script>window.location.href = 'registration.php';</script>";
    } else {
        // Hash the password before storing
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);

        // Insert new user data into the database
        $stmt = $conn->prepare("INSERT INTO users (id_number, name, email, password, role, security_question, security_answer, profile_picture) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("ssssssss", $id_number, $name, $email, $hashed_password, $role, $security_question, $security_answer, $profile_picture_path);

        if ($stmt->execute()) {
            echo "<script>alert('Registration successful! You can now log in.');</script>";
            echo "<script>window.location.href = 'login.php';</script>";
        } else {
            echo "<script>alert('Error registering user. Please try again later.');</script>";
        }
    }

    $stmt->close();
    $conn->close();
}
?>
