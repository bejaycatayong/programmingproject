-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 24, 2024 at 01:15 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.1.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dbfinaltermproject`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbadminreport`
--

CREATE TABLE `tbadminreport` (
  `report_id` int(11) NOT NULL,
  `faculty_id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `violation_id` int(11) NOT NULL,
  `faculty_report` text DEFAULT NULL,
  `report_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `student_response` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbadminreport`
--

INSERT INTO `tbadminreport` (`report_id`, `faculty_id`, `student_id`, `violation_id`, `faculty_report`, `report_date`, `student_response`) VALUES
(34, 24, 20, 1, 'bayannn', '2024-11-24 12:02:41', 'why?');

-- --------------------------------------------------------

--
-- Table structure for table `tbviolations`
--

CREATE TABLE `tbviolations` (
  `Violation` varchar(255) NOT NULL,
  `Sanction` varchar(255) NOT NULL,
  `violation_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbviolations`
--

INSERT INTO `tbviolations` (`Violation`, `Sanction`, `violation_id`) VALUES
('Tardiness (3 counts)', 'Admission Slip from Student Development Office - Upload jpg file', 1),
('Absences (3 or more consecutive, >7 count)', 'Admission Slip from Student Development Office - Upload jpg file', 2),
('Use of mobile phone/e-devices during class session', 'Construct an explanatory letter address to the faculty to abide and keep all electronic gadgets away inside your personal belongings, wear ID, proper uniform without caps and other head accessories in the whole lecture and laboratory sessions. - paragraph', 3),
('No ID inside the class', 'Construct an explanatory letter address to the faculty on the reasons of not wearing an ID. - paragraph text entry in the system', 4),
('Accessing social networking sites, video streaming sites, or others which are irrelevant to the course during laboratory sessions.', 'Construct an explanatory letter address to the faculty on the reasons of prohibited site access. - paragraph text entry in the system', 5),
('Wearing of caps and headset accessories during class session.', 'Construct an explanatory letter address to the faculty on the reasons of wearing caps and headset accessories during class session. - paragraph text entry in the system', 6);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `id_number` varchar(15) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('student','faculty','admin') NOT NULL,
  `security_question` varchar(255) NOT NULL,
  `security_answer` varchar(255) NOT NULL,
  `profile_picture` varchar(255) DEFAULT 'uploads/profile_pictures/default.png'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `id_number`, `name`, `email`, `password`, `role`, `security_question`, `security_answer`, `profile_picture`) VALUES
(15, '12345', 'adminaccount', 'adminaccount@gmail.com', '$2y$10$6eniLMulitJ/pUCKq6JWTu27cIUfoCNtOhsCZPgy9hemJVXtP4wFi', 'admin', '', '', 'uploads/profile_pictures/15_15_phong.png'),
(20, '123', 'student', 'student@gmail.com', '$2y$10$mar.eSUWEjy2RE/qQPaP8ONvBnzajl42EdPXFrIME106gyL.s9nni', 'student', 'What is your favorite color?', 'blue', 'uploads/profile_pictures/20_15_phong.png'),
(24, '1234', 'facultyaccount', 'faculty@gmail.com', '$2y$10$Qslxnl50DmQ.8mYSZocBvePmx/KQdWOFDDRWSbyfIJRTh/0lNKRJm', 'faculty', 'What is your favorite color?', 'blue', 'uploads/profile_pictures/24_sql.png'),
(30, '123455', 'newadmin', 'newadmin@gmail.com', '$2y$10$wB4DWAgRHMuhbgbywAPtCOY0SZbTgQkpT0ZSY8.uuFUtKvfQY4UbO', 'admin', 'What is your favorite color?', 'blue', 'uploads/profile_pictures/123455_sql.png');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbadminreport`
--
ALTER TABLE `tbadminreport`
  ADD PRIMARY KEY (`report_id`),
  ADD KEY `violation_id` (`violation_id`),
  ADD KEY `tbadminreport_ibfk_1` (`faculty_id`),
  ADD KEY `tbadminreport_ibfk_2` (`student_id`);

--
-- Indexes for table `tbviolations`
--
ALTER TABLE `tbviolations`
  ADD PRIMARY KEY (`violation_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id_number` (`id_number`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbadminreport`
--
ALTER TABLE `tbadminreport`
  MODIFY `report_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;

--
-- AUTO_INCREMENT for table `tbviolations`
--
ALTER TABLE `tbviolations`
  MODIFY `violation_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `tbadminreport`
--
ALTER TABLE `tbadminreport`
  ADD CONSTRAINT `tbadminreport_ibfk_1` FOREIGN KEY (`faculty_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `tbadminreport_ibfk_2` FOREIGN KEY (`student_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `tbadminreport_ibfk_3` FOREIGN KEY (`violation_id`) REFERENCES `tbviolations` (`violation_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
