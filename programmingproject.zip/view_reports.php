<?php
session_start();

if (!isset($_SESSION['user']) || $_SESSION['user']['role'] != 'admin') {
    header("Location: login.php");
    exit;
}

$user = $_SESSION['user'];
include 'mysql_connect.php';

$query = "
    SELECT 
        ar.report_id,
        v.Violation,
        v.Sanction,
        ar.faculty_report,
        ar.student_response,
        ar.report_date,
        s.id_number AS StudentID,
        f.id_number AS FacultyID
    FROM tbadminreport ar
    JOIN tbviolations v ON ar.violation_id = v.violation_id
    JOIN users s ON ar.student_id = s.id
    JOIN users f ON ar.faculty_id = f.id
";
$result = $conn->query($query);

$reports = [];
while ($row = $result->fetch_assoc()) {
    $reports[] = $row;
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Reports</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            padding: 20px;
        }
        .container {
            max-width: 1000px;
            margin: auto;
            background: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
        }
        th, td {
            text-align: left;
            padding: 10px;
            border-bottom: 1px solid #ddd;
        }
        th {
            background-color: #003399;
            color: white;
        }
        button {
            margin: 10px 0;
            padding: 10px;
            width: 10%;
            background-color: #003399;
            color: white;
            border: none;
            border-radius: 5px;
            font-size: 16px;
            cursor: pointer;
        }
        button:hover {
            background-color: #FFD700;
            color: #003399;
        }
    </style>
</head>
<body>
    <div class="container">
    <button onclick="window.location.href='admin_dashboard.php'">Back</button>
        <h1>Violation Reports</h1>
        <table>
            <thead>
                <tr>
                    <th>Violation</th>
                    <th>Sanction</th>
                    <th>Faculty Report</th>
                    <th>Student Response</th>
                    <th>Reported (Faculty)</th>
                    <th>Student</th>
                    <th>Date</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($reports)) { ?>
                    <tr>
                        <td colspan="7">No reports found.</td>
                    </tr>
                <?php } else { ?>
                    <?php foreach ($reports as $report) { ?>
                        <tr>
                            <td><?php echo htmlspecialchars($report['Violation']); ?></td>
                            <td><?php echo htmlspecialchars($report['Sanction']); ?></td>
                            <td><?php echo htmlspecialchars($report['faculty_report'] ?? 'No Report'); ?></td>
                            <td><?php echo htmlspecialchars($report['student_response'] ?? 'No Response'); ?></td>
                            <td><?php echo htmlspecialchars($report['FacultyID']); ?></td>
                            <td><?php echo htmlspecialchars($report['StudentID']); ?></td>
                            <td><?php echo htmlspecialchars($report['report_date']); ?></td>
                        </tr>
                    <?php } ?>
                <?php } ?>
            </tbody>
        </table>
    </div>
</body>
</html>
