<?php
session_start();

if (!isset($_SESSION['user']) || $_SESSION['user']['role'] != 'admin') {
    header("Location: login.php");
    exit;
}

include 'mysql_connect.php';

$students = [];
$faculty = [];

$stmt = $conn->prepare("SELECT id, id_number, name, email, role FROM users WHERE role = 'student'");
if ($stmt) {
    $stmt->execute();
    $result = $stmt->get_result();
    while ($row = $result->fetch_assoc()) {
        $students[] = $row;
    }
    $stmt->close();
}

$stmt = $conn->prepare("SELECT id, id_number, name, email, role FROM users WHERE role = 'faculty'");
if ($stmt) {
    $stmt->execute();
    $result = $stmt->get_result();
    while ($row = $result->fetch_assoc()) {
        $faculty[] = $row;
    }
    $stmt->close();
}


if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['edit_user'])) {
        $id = $_POST['id'];
        $name = $_POST['name'];
        $email = $_POST['email'];

        $stmt = $conn->prepare("UPDATE users SET name = ?, email = ? WHERE id = ?");
        $stmt->bind_param("ssi", $name, $email, $id);

        if ($stmt->execute()) {
            echo "<script>alert('User updated successfully.');</script>";
        } else {
            echo "<script>alert('Error updating user.');</script>";
        }

        $stmt->close();
        header("Location: manage_users.php");
        exit;
    } elseif (isset($_POST['delete_user'])) {
        $id = $_POST['id'];

        $stmt = $conn->prepare("DELETE FROM users WHERE id = ?");
        $stmt->bind_param("i", $id);

        if ($stmt->execute()) {
            echo "<script>alert('User deleted successfully.');</script>";
        } else {
            echo "<script>alert('Error deleting user.');</script>";
        }

        $stmt->close();
        header("Location: manage_users.php");
        exit;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Users</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            padding: 20px;
        }
        .container {
            max-width: 1000px;
            margin: auto;
            background: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        .tabs {
            display: flex;
            margin-bottom: 20px;
        }
        .tab {
            flex: 1;
            text-align: center;
            padding: 10px;
            cursor: pointer;
            background-color: #003399;
            color: white;
            border-radius: 5px 5px 0 0;
        }
        .tab.active {
            background-color: #FFD700;
            color: #003399;
        }
        .tab-content {
            display: none;
        }
        .tab-content.active {
            display: block;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        th, td {
            padding: 10px;
            border-bottom: 1px solid #ddd;
            text-align: center;
        }
        th {
            background-color: #003399;
            color: white;
        }
        button {
            padding: 8px 12px;
            margin: 5px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        .edit-button {
            background-color: #4CAF50;
            color: white;
        }
        .edit-button:hover {
            background-color: #45a049;
        }
        .delete-button {
            background-color: #f44336;
            color: white;
        }
        .delete-button:hover {
            background-color: #d32f2f;
        }
        .back-button {
            background-color: #003399;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            font-size: 16px;
            cursor: pointer;
            margin-bottom: 20px;
        }
        .back-button:hover {
            background-color: #FFD700;
            color: #003399;
        }
        .modal {
            display: none;
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            background: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
            z-index: 1000;
        }
        .modal.active {
            display: block;
        }
        .overlay {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.5);
            z-index: 999;
        }
        .overlay.active {
            display: block;
        }
    </style>
    <script>
        function showTab(tabId) {
            const tabs = document.querySelectorAll('.tab-content');
            tabs.forEach(tab => tab.classList.remove('active'));

            const activeTab = document.getElementById(tabId);
            activeTab.classList.add('active');

            const tabButtons = document.querySelectorAll('.tab');
            tabButtons.forEach(button => button.classList.remove('active'));

            document.querySelector(`[data-tab="${tabId}"]`).classList.add('active');
        }

        function openEditModal(id, name, email) {
            document.getElementById('edit-id').value = id;
            document.getElementById('edit-name').value = name;
            document.getElementById('edit-email').value = email;
            document.querySelector('.modal').classList.add('active');
            document.querySelector('.overlay').classList.add('active');
        }

        function closeEditModal() {
            document.querySelector('.modal').classList.remove('active');
            document.querySelector('.overlay').classList.remove('active');
        }
    </script>
</head>
<body>
    <div class="overlay" onclick="closeEditModal()"></div>
    <div class="modal">
        <h2>Edit User</h2>
        <form action="manage_users.php" method="post">
            <input type="hidden" id="edit-id" name="id">
            <label for="edit-name">Name:</label>
            <input type="text" id="edit-name" name="name" required>
            <label for="edit-email">Email:</label>
            <input type="email" id="edit-email" name="email" required>
            <button type="submit" name="edit_user" class="edit-button">Save Changes</button>
            <button type="button" class="delete-button" onclick="closeEditModal()">Cancel</button>
        </form>
    </div>

    <div class="container">
        <button class="back-button" onclick="window.location.href='admin_dashboard.php'">Back</button>


        <h1>Manage Users</h1>

        <div class="tabs">
            <div class="tab active" data-tab="students-tab" onclick="showTab('students-tab')">Student Accounts</div>
            <div class="tab" data-tab="faculty-tab" onclick="showTab('faculty-tab')">Faculty Accounts</div>
        </div>

        <div id="students-tab" class="tab-content active">
            <h2>Student Accounts</h2>
            <table>
                <thead>
                    <tr>
                        <th>ID Number</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Role</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($students as $student) { ?>
                        <tr>
                            <td><?php echo htmlspecialchars($student['id_number']); ?></td>
                            <td><?php echo htmlspecialchars($student['name']); ?></td>
                            <td><?php echo htmlspecialchars($student['email']); ?></td>
                            <td><?php echo htmlspecialchars($student['role']); ?></td>
                            <td>
                                <button class="edit-button" onclick="openEditModal('<?php echo $student['id']; ?>', '<?php echo htmlspecialchars($student['name']); ?>', '<?php echo htmlspecialchars($student['email']); ?>')">Edit</button>
                                <form action="manage_users.php" method="post" style="display: inline;">
                                    <input type="hidden" name="id" value="<?php echo $student['id']; ?>">
                                    <button type="submit" name="delete_user" class="delete-button" onclick="return confirm('Are you sure you want to delete this user?');">Delete</button>
                                </form>
                            </td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>

        <div id="faculty-tab" class="tab-content">
            <h2>Faculty Accounts</h2>
            <table>
                <thead>
                    <tr>
                        <th>ID Number</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Role</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($faculty as $member) { ?>
                        <tr>
                            <td><?php echo htmlspecialchars($member['id_number']); ?></td>
                            <td><?php echo htmlspecialchars($member['name']); ?></td>
                            <td><?php echo htmlspecialchars($member['email']); ?></td>
                            <td><?php echo htmlspecialchars($member['role']); ?></td>
                            <td>
                                <button class="edit-button" onclick="openEditModal('<?php echo $member['id']; ?>', '<?php echo htmlspecialchars($member['name']); ?>', '<?php echo htmlspecialchars($member['email']); ?>')">Edit</button>
                                <form action="manage_users.php" method="post" style="display: inline;">
                                    <input type="hidden" name="id" value="<?php echo $member['id']; ?>">
                                    <button type="submit" name="delete_user" class="delete-button" onclick="return confirm('Are you sure you want to delete this user?');">Delete</button>
                                </form>
                            </td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
    </div>
</body>
</html>
