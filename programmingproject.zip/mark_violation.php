<?php
session_start();

// Check if the user is logged in and is a faculty member
if (!isset($_SESSION['user']) || $_SESSION['user']['role'] != 'faculty') {
    header("Location: login.php");
    exit;
}

$user = $_SESSION['user']; // Retrieve user details from the session
include 'mysql_connect.php';

// Fetch students
$stmt = $conn->prepare("SELECT id, id_number, name FROM users WHERE role = 'student'");
$stmt->execute();
$students = $stmt->get_result();

// Fetch violations
$stmt2 = $conn->prepare("SELECT violation_id, Violation FROM tbviolations");
$stmt2->execute();
$violations = $stmt2->get_result();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $student_id = $_POST['student_id'];
    $violation_id = $_POST['violation_id'];
    $faculty_report = $_POST['faculty_report'];

    // Insert the violation report into tbadminreport
    $stmt3 = $conn->prepare("INSERT INTO tbadminreport (faculty_id, student_id, violation_id, faculty_report) VALUES (?, ?, ?, ?)");
    $stmt3->bind_param("iiis", $user['id'], $student_id, $violation_id, $faculty_report);

    if ($stmt3->execute()) {
        echo "<script>alert('Violation assigned successfully.');</script>";
        echo "<script>window.location.href = 'faculty_dashboard.php';</script>";
    } else {
        echo "<script>alert('Error assigning violation. Please try again.');</script>";
    }

    $stmt3->close();
    $conn->close();
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mark Violation</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            padding: 20px;
        }
        .container {
            max-width: 600px;
            margin: auto;
            background: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        select, textarea, button {
            width: 100%;
            margin: 10px 0;
            padding: 10px;
            font-size: 16px;
        }
        textarea {
            height: 100px;
        }
        button {
            background-color: #003399;
            color: white;
            border: none;
            cursor: pointer;
        }
        button:hover {
            background-color: #FFD700;
            color: #003399;
        }
        .cancel {
            background-color: #f44336; /* Red */
        }
        .cancel:hover {
            background-color: #d32f2f; /* Darker red */
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Mark Violation</h1>
        <form action="mark_violation.php" method="post">
            <label for="student_id">Select Student:</label>
            <select id="student_id" name="student_id" required>
                <option value="" disabled selected>Select a Student</option>
                <?php while ($student = $students->fetch_assoc()) { ?>
                    <option value="<?php echo $student['id']; ?>"><?php echo $student['id_number'] . " - " . $student['name']; ?></option>
                <?php } ?>
            </select>

            <label for="violation_id">Select Violation:</label>
            <select id="violation_id" name="violation_id" required>
                <option value="" disabled selected>Select a Violation</option>
                <?php while ($violation = $violations->fetch_assoc()) { ?>
                    <option value="<?php echo $violation['violation_id']; ?>"><?php echo $violation['Violation']; ?></option>
                <?php } ?>
            </select>

            <label for="faculty_report">Faculty Report:</label>
            <textarea id="faculty_report" name="faculty_report" placeholder="Provide details about the violation" required></textarea>

            <button type="submit">Assign Violation</button>
        </form>
        <button class="cancel" onclick="window.location.href='faculty_dashboard.php'">Cancel</button>
    </div>
</body>
</html>
