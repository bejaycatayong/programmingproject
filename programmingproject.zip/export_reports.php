<?php
include 'mysql_connect.php';


$student_id = $_GET['student_id'] ?? '';
$violation_id = $_GET['violation_id'] ?? '';
$start_date = $_GET['start_date'] ?? '';
$end_date = $_GET['end_date'] ?? '';


$query = "
    SELECT ar.report_id, v.Violation, v.Sanction, ar.faculty_report, ar.report_date, ar.student_response, s.id_number AS StudentID, s.name AS StudentName
    FROM tbadminreport ar
    JOIN tbviolations v ON ar.violation_id = v.violation_id
    JOIN users s ON ar.student_id = s.id
    WHERE 1=1
";
$params = [];
$types = '';

if (!empty($student_id)) {
    $query .= " AND s.id_number = ?";
    $params[] = $student_id;
    $types .= 's';
}
if (!empty($violation_id)) {
    $query .= " AND v.violation_id = ?";
    $params[] = $violation_id;
    $types .= 'i';
}
if (!empty($start_date) && !empty($end_date)) {
    $query .= " AND ar.report_date BETWEEN ? AND ?";
    $params[] = $start_date;
    $params[] = $end_date;
    $types .= 'ss';
}

$stmt = $conn->prepare($query);
if (!empty($params)) {
    $stmt->bind_param($types, ...$params);
}
$stmt->execute();
$result = $stmt->get_result();


header('Content-Type: text/csv');
header('Content-Disposition: attachment; filename="reports.csv"');
$output = fopen('php://output', 'w');
fputcsv($output, ['Student ID', 'Student Name', 'Violation', 'Sanction', 'Faculty Report', 'Student Response', 'Report Date']);

while ($row = $result->fetch_assoc()) {
    fputcsv($output, [
        $row['StudentID'],
        $row['StudentName'],
        $row['Violation'],
        $row['Sanction'],
        $row['faculty_report'],
        $row['student_response'] ?? 'No Response',
        $row['report_date']
    ]);
}
fclose($output);

$stmt->close();
$conn->close();
exit;
?>
