<?php
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit;
}

include 'mysql_connect.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $student_id = $_SESSION['user']['id'];
    $violation_id = $_POST['violation_id'];
    $student_response = $_POST['student_response'];

    $stmt = $conn->prepare("UPDATE tbadminreport SET student_response = ? WHERE student_id = ? AND violation_id = ?");
    $stmt->bind_param("sii", $student_response, $student_id, $violation_id);
    $stmt->execute();
    $stmt->close();

    header("Location: student_dashboard.php");
    exit;
}
?>
