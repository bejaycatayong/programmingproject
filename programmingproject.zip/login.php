<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - JRU System</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }
        .container {
            width: 100%;
            max-width: 400px;
            margin: 100px auto;
            background: #fff;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            padding: 20px;
            text-align: center;
        }
        .header {
            color: #003399;
            font-size: 24px;
            font-weight: bold;
        }
        input[type="text"], input[type="password"] {
            width: 90%;
            padding: 10px;
            margin: 10px 0;
            border: 1px solid #ccc;
            border-radius: 5px;
        }
        button {
            background-color: #003399;
            color: white;
            padding: 10px 15px;
            border: none;
            border-radius: 5px;
            font-size: 16px;
        }
        button:hover {
            background-color: #FFD700;
            color: #003399;
        }
        a {
            text-decoration: none;
            color: #003399;
            display: inline-block;
            margin-top: 10px;
        }
        a:hover {
            color: #FFD700;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">Sign In</div>
        <form action="login_process.php" method="post">
            <input type="text" name="id_number" placeholder="ID Number" required>
            <input type="password" name="password" placeholder="Password" required>
            <button type="submit">Login</button>
        </form>
        <a href="forgot_password.php">Forgot Password?</a>
        <p>Don't have an account? <a href="registration.php">Create Account</a></p>
    </div>
</body>
</html>
