<?php
session_start();

if (!isset($_SESSION['user']) || $_SESSION['user']['role'] != 'admin') {
    header("Location: login.php");
    exit;
}

$user = $_SESSION['user']; 
include 'mysql_connect.php';

$success_message = "";

$stmt = $conn->prepare("SELECT * FROM tbviolations");
$stmt->execute();
$result = $stmt->get_result();

$violations = [];
while ($row = $result->fetch_assoc()) {
    $violations[] = $row;

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['add_violation'])) {
        $violation = $_POST['violation'];
        $sanction = $_POST['sanction'];

        $stmt2 = $conn->prepare("INSERT INTO tbviolations (Violation, Sanction) VALUES (?, ?)");
        $stmt2->bind_param("ss", $violation, $sanction);
        $stmt2->execute();
        $stmt2->close();

        $success_message = "Violation added successfully!";
        header("Location: manage_violations.php");
        exit;
    } elseif (isset($_POST['edit_violation'])) {
        $violation_id = $_POST['violation_id'];
        $violation = $_POST['violation'];
        $sanction = $_POST['sanction'];

        $stmt2 = $conn->prepare("UPDATE tbviolations SET Violation = ?, Sanction = ? WHERE violation_id = ?");
        $stmt2->bind_param("ssi", $violation, $sanction, $violation_id);
        $stmt2->execute();
        $stmt2->close();

        $success_message = "Violation updated successfully!";
        header("Location: manage_violations.php");
        exit;
    } elseif (isset($_POST['delete_violation'])) {
        $violation_id = $_POST['violation_id'];

        $stmt2 = $conn->prepare("DELETE FROM tbviolations WHERE violation_id = ?");
        $stmt2->bind_param("i", $violation_id);
        $stmt2->execute();
        $stmt2->close();

        $success_message = "Violation deleted successfully!";
        header("Location: manage_violations.php");
        exit;
    }
}
}

$stmt->close();
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Violations</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            padding: 20px;
        }
        .container {
            max-width: 800px;
            margin: auto;
            background: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
        }
        th, td {
            text-align: left;
            padding: 10px;
            border-bottom: 1px solid #ddd;
        }
        th {
            background-color: #003399;
            color: white;
        }
        textarea {
            width: calc(100% - 20px);
            height: 100px;
            margin: 10px 0;
            padding: 10px;
            font-size: 16px;
            resize: vertical;
        }
        button {
            margin: 5px;
            padding: 10px 20px;
            background-color: #003399;
            color: white;
            border: none;
            border-radius: 5px;
            font-size: 16px;
            cursor: pointer;
        }
        button:hover {
            background-color: #FFD700;
            color: #003399;
        }
        .cancel {
            background-color: #f44336;
        }
        .cancel:hover {
            background-color: #d32f2f;
        }
        .success-message {
            background-color: #4CAF50;
            color: white;
            padding: 15px;
            margin-bottom: 20px;
            border-radius: 5px;
            text-align: center;
        }
    </style>
</head>
<body>
    <div class="container">
    <button onclick="window.location.href='admin_dashboard.php'">Back</button>
        <h1>Manage Violations</h1>

        <?php if ($success_message) { ?>
            <div class="success-message">
                <?php echo $success_message; ?>
            </div>
        <?php } ?>

        <h3>Add New Violation</h3>
        <form action="manage_violations.php" method="post">
            <label for="violation">Violation:</label>
            <textarea id="violation" name="violation" required></textarea>

            <label for="sanction">Sanction:</label>
            <textarea id="sanction" name="sanction" required></textarea>

            <button type="submit" name="add_violation">Add Violation</button>
        </form>

        <h3>Existing Violations</h3>
        <table>
            <thead>
                <tr>
                    <th>Violation</th>
                    <th>Sanction</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($violations)) { ?>
                    <tr>
                        <td colspan="3">No violations found.</td>
                    </tr>
                <?php } else { ?>
                    <?php foreach ($violations as $violation) { ?>
                        <tr>
                            <td><?php echo htmlspecialchars($violation['Violation']); ?></td>
                            <td><?php echo htmlspecialchars($violation['Sanction']); ?></td>
                            <td>
                                <button onclick="document.getElementById('edit_<?php echo $violation['violation_id']; ?>').style.display='block'">Edit</button>

                                <form action="manage_violations.php" method="post" style="display:inline;">
                                    <input type="hidden" name="violation_id" value="<?php echo $violation['violation_id']; ?>">
                                    <button type="submit" name="delete_violation" class="cancel">Delete</button>
                                </form>
                            </td>
                        </tr>
                        <div id="edit_<?php echo $violation['violation_id']; ?>" style="display:none;">
                            <form action="manage_violations.php" method="post">
                                <input type="hidden" name="violation_id" value="<?php echo $violation['violation_id']; ?>">
                                <label for="violation">Violation:</label>
                                <textarea name="violation" required><?php echo htmlspecialchars($violation['Violation']); ?></textarea>

                                <label for="sanction">Sanction:</label>
                                <textarea name="sanction" required><?php echo htmlspecialchars($violation['Sanction']); ?></textarea>

                                <button type="submit" name="edit_violation">Save Changes</button>
                                <button type="button" onclick="document.getElementById('edit_<?php echo $violation['violation_id']; ?>').style.display='none'">Cancel</button>
                            </form>
                        </div>
                    <?php } ?>
                <?php } ?>
            </tbody>
        </table>
    </div>
</body>
</html>
