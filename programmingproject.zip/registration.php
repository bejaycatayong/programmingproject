<?php
include 'mysql_connect.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id_number = $_POST['id_number'];
    $name = $_POST['name'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $role = $_POST['role'];
    $security_question = $_POST['security_question'];
    $security_answer = $_POST['security_answer'];
    $profile_picture = $_POST['profile_picture'];

    $stmt = $conn->prepare("SELECT * FROM users WHERE id_number = ? OR email = ?");
    $stmt->bind_param("ss", $id_number, $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        echo "<script>alert('Email or ID number already exists. Please try again.');</script>";
    } else {
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);

        $stmt = $conn->prepare("INSERT INTO users (id_number, name, email, password, role, security_question, security_answer, profile_picture) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("sssssss", $id_number, $name, $email, $hashed_password, $role, $security_question, $security_answer, $profile_picture);

        if ($stmt->execute()) {
            echo "<script>alert('Registration successful! You can now log in.');</script>";
            echo "<script>window.location.href = 'login.php';</script>";
        } else {
            echo "<script>alert('Error registering user. Please try again later.');</script>";
        }
    }

    $stmt->close();
    $conn->close();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Register - JRU System</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
        }
        .container {
            max-width: 400px;
            margin: 100px auto;
            background: #fff;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        input, select, button {
            width: 100%;
            margin: 10px 0;
            padding: 10px;
        }
        button {
            background-color: #003399;
            color: #fff;
            border: none;
            cursor: pointer;
        }
        button:hover {
            background-color: #FFD700;
            color: #003399;
        }
        a {
            text-decoration: none;
            color: #003399;
        }
    </style>
</head>
<body>
        <div class="container" style="text-align: center;">
        <h1>Register</h1>
        <form action="register_process.php" method="post" enctype="multipart/form-data">
            <input type="file" id="profile_picture" name="profile_picture" accept="image/*">
            <input type="text" name="id_number" placeholder="ID Number" required pattern="\d+" title="ID Number must contain only numbers">
            <input type="text" name="name" placeholder="Full Name" required>
            <input type="email" name="email" placeholder="Email Address" required>
            <input type="password" name="password" placeholder="Password" required>
            <select name="role" required>
               <option value="student">Student</option>
                <option value="faculty">Faculty</option>
                <option value="admin">Admin</option>
            </select>
            <select name="security_question" required>
                <option value="What is your favorite color?">What is your favorite color?</option>
                <option value="What is your mother’s maiden name?">What is your mother’s maiden name?</option>
             <option value="What is the name of your first pet?">What is the name of your first pet?</option>
          </select>
         <input type="text" name="security_answer" placeholder="Answer to your question" required>
    <button type="submit">Register</button>
</form>
        <p>Already have an account? <a href="login.php">Login here</a></p>
    </div>
</body>
</html>
