<?php
session_start();

if (!isset($_SESSION['user']) || $_SESSION['user']['role'] != 'student') {
    header("Location: login.php");
    exit;
}

$user = $_SESSION['user'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Dashboard</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            padding: 20px;
        }
        .container {
            max-width: 600px;
            margin: auto;
            background: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            text-align: center;
        }
        button {
            width: 100%;
            margin: 10px 0;
            padding: 10px;
            background-color: #003399;
            color: white;
            border: none;
            border-radius: 5px;
            font-size: 16px;
            cursor: pointer;
        }
        button:hover {
            background-color: #FFD700;
            color: #003399;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Student Dashboard</h1>
        <img src="<?php echo htmlspecialchars($user['profile_picture']); ?>" alt="Profile Picture" style="width:150px; height:150px; border-radius:50%;"><br>
        <p><strong>Welcome, <?php echo htmlspecialchars($user['name']); ?></strong></p>
        <p><strong>Role:</strong> Student</p>
        <button onclick="window.location.href='view_profile.php'">View Profile</button>
        <button onclick="window.location.href='view_violations.php'">View Violations</button>
        <button onclick="window.location.href='students_violations.php'">Respond to Violations</button>
        <button onclick="window.location.href='logout.php'">Logout</button>
    </div>
</body>
</html>
