<?php
session_start();

if (!isset($_SESSION['user']) || $_SESSION['user']['role'] != 'student') {
    header("Location: login.php");
    exit;
}

$user = $_SESSION['user'];
include 'mysql_connect.php';

if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    echo "<script>alert('Invalid violation ID.');</script>";
    echo "<script>window.location.href = 'student_violations.php';</script>";
    exit;
}

$report_id = $_GET['id'];

$stmt = $conn->prepare("
    SELECT ar.report_id, v.Violation, v.Sanction, ar.faculty_report, ar.report_date, ar.student_response
    FROM tbadminreport ar
    JOIN tbviolations v ON ar.violation_id = v.violation_id
    WHERE ar.report_id = ? AND ar.student_id = ?
");
$stmt->bind_param("ii", $report_id, $user['id']);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows == 0) {
    echo "<script>alert('Violation not found or you do not have permission to respond to this violation.');</script>";
    echo "<script>window.location.href = 'student_violations.php';</script>";
    exit;
}

$violation = $result->fetch_assoc();
$stmt->close();


if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $response = $_POST['response'];


    $stmt = $conn->prepare("UPDATE tbadminreport SET student_response = ? WHERE report_id = ?");
    $stmt->bind_param("si", $response, $report_id);

    if ($stmt->execute()) {
        echo "<script>alert('Response submitted successfully.');</script>";
        echo "<script>window.location.href = 'students_violations.php';</script>";
    } else {
        echo "<script>alert('Error submitting response. Please try again.');</script>";
    }

    $stmt->close();
    $conn->close();
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Respond to Violation</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            padding: 20px;
        }
        .container {
            max-width: 600px;
            margin: auto;
            background: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        textarea, button {
            width: 100%;
            margin: 10px 0;
            padding: 10px;
            font-size: 16px;
        }
        textarea {
            height: 100px;
        }
        button {
            background-color: #003399;
            color: white;
            border: none;
            cursor: pointer;
        }
        button:hover {
            background-color: #FFD700;
            color: #003399;
        }
        .back {
            background-color: #f44336;
        }
        .back:hover {
            background-color: #d32f2f;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Respond to Violation</h1>
        <p><strong>Violation:</strong> <?php echo htmlspecialchars($violation['Violation']); ?></p>
        <p><strong>Sanction:</strong> <?php echo htmlspecialchars($violation['Sanction']); ?></p>
        <p><strong>Faculty Report:</strong> <?php echo htmlspecialchars($violation['faculty_report']); ?></p>
        <p><strong>Reported On:</strong> <?php echo htmlspecialchars($violation['report_date']); ?></p>

        <form action="respond_violation.php?id=<?php echo $report_id; ?>" method="post">
            <label for="response">Your Response:</label>
            <textarea id="response" name="response" required><?php echo htmlspecialchars($violation['student_response'] ?? ''); ?></textarea>
            <button type="submit">Submit Response</button>
        </form>
        <button onclick="window.history.back()">Back</button>
    </div>
</body>
</html>
