<?php
session_start();

if (!isset($_SESSION['user']) || $_SESSION['user']['role'] != 'student') {
    header("Location: login.php");
    exit;
}

$user = $_SESSION['user'];
include 'mysql_connect.php';

$stmt = $conn->prepare("
    SELECT ar.report_id, v.Violation, v.Sanction, ar.report_date, ar.student_response
    FROM tbadminreport ar
    JOIN tbviolations v ON ar.violation_id = v.violation_id
    WHERE ar.student_id = ?
");
$stmt->bind_param("i", $user['id']);
$stmt->execute();
$result = $stmt->get_result();

$violations = [];
while ($row = $result->fetch_assoc()) {
    $violations[] = $row;
}

$stmt->close();
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Violations</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            padding: 20px;
        }
        .container {
            max-width: 800px;
            margin: auto;
            background: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
        }
        th, td {
            text-align: left;
            padding: 10px;
            border-bottom: 1px solid #ddd;
        }
        th {
            background-color: #003399;
            color: white;
        }
        button {
            margin: 10px 0;
            padding: 10px;
            width: 100%;
            background-color: #003399;
            color: white;
            border: none;
            border-radius: 5px;
            font-size: 16px;
            cursor: pointer;
        }
        button:hover {
            background-color: #FFD700;
            color: #003399;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>My Violations</h1>
        <table>
            <thead>
                <tr>
                    <th>Violation</th>
                    <th>Sanction</th>
                    <th>Date</th>
                    <th>Response</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($violations)) { ?>
                    <tr>
                        <td colspan="5">No violations found.</td>
                    </tr>
                <?php } else { ?>
                    <?php foreach ($violations as $violation) { ?>
                        <tr>
                            <td><?php echo htmlspecialchars($violation['Violation']); ?></td>
                            <td><?php echo htmlspecialchars($violation['Sanction']); ?></td>
                            <td><?php echo htmlspecialchars($violation['report_date']); ?></td>
                            <td><?php echo htmlspecialchars($violation['student_response'] ?? 'No Response'); ?></td>
                            <td><button onclick="window.location.href='respond_violation.php?id=<?php echo $violation['report_id']; ?>'">Respond</button></td>
                        </tr>
                    <?php } ?>
                <?php } ?>
            </tbody>
        </table>
        <button onclick="window.location.href='student_dashboard.php'">Back</button>
    </div>
</body>
</html>
