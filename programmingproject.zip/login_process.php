<?php
include 'mysql_connect.php';
session_start();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id_number = filter_input(INPUT_POST, 'id_number', FILTER_SANITIZE_STRING);
    $password = $_POST['password'];

    if (!$id_number || !$password) {
        echo "<script>alert('Please enter your ID number and password.');</script>";
        echo "<script>window.location.href = 'login.php';</script>";
        exit;
    }

    $stmt = $conn->prepare("SELECT * FROM users WHERE id_number = ?");
    $stmt->bind_param("s", $id_number);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();
        if (password_verify($password, $user['password'])) {
            $_SESSION['user'] = $user;

            switch ($user['role']) {
                case 'student':
                    header("Location: student_dashboard.php");
                    break;
                case 'faculty':
                    header("Location: faculty_dashboard.php");
                    break;
                case 'admin':
                    header("Location: admin_dashboard.php");
                    break;
            }
            exit;
        } else {
            echo "<script>alert('Incorrect password. Please try again.');</script>";
        }
    } else {
        echo "<script>alert('Invalid ID number. Please try again.');</script>";
    }

    echo "<script>window.location.href = 'login.php';</script>";
    $stmt->close();
    $conn->close();
}
?>
