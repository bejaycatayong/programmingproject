<?php
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit;
}

include 'mysql_connect.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $report_id = $_POST['report_id'];
    $response = $_POST['response'];

    $query = "UPDATE tbadminreport SET report_details = ? WHERE report_id = ?";

    if ($stmt = $conn->prepare($query)) {
        $stmt->bind_param("si", $response, $report_id);
        $stmt->execute();
        echo "Response submitted successfully.";
    } else {
        echo "Error submitting response.";
    }
}
?>
